% part C
clear;
N_0 = 32;

%C1
Omega_0 = 2*pi/N_0;
H = zeros(1, N_0); % H for one period
H(1:5) = 1;
H(29:32) = 1;

clf;
subplot(311);
omega = -2*pi:Omega_0:2*pi;
stem(omega, [H H H(1)]);
xlabel("\omega"); ylabel("H[\omega]");
xticks([-2*pi -pi -3*pi/4 -pi/4 0 pi/4 3*pi/4 pi 2*pi]);
xticklabels({'-2\pi', '-\pi', '-3\pi/4', '-\pi/4', '0' '\pi/4', '3\pi/4', '\pi', '2\pi'});
title("C1: H[r] with respect to \Omega_0");
axis([-2*pi 2*pi -inf inf]);

%C2
%{
Note for C2 and C3:
On page 889 of Linear Systems and Signals 3e, X = fft(x)/N_0 whereas
x = real(ifft(X)*N_0). Using X = real(fft(x)/N_0) produces a different y2.
%}

n = 0:N_0-1;
n_plot = -32:32;
x1 = 4*cos(pi*n/8);
X1 = fft(x1)/N_0;
Y1 = X1.*H;
y1 = real(ifft(Y1)*N_0);

subplot(312);
stem(n_plot,[y1 y1 y1(1)]);
xticks([-32 -16 -12 -4 0 4 12 16 32]);
xlabel("n"); ylabel("y_1[n]");
title("C2: y_1[n] = x_1[n] * h[n]");
axis([-32 32 -inf inf]);

%C3
x2 = 4*cos(pi*n/2);
X2 = fft(x2)/N_0;
Y2 = X2.*H;
y2 = real(ifft(Y2)*N_0);

subplot(313);
stem(n_plot,[y2 y2 y2(1)]);
xlabel("n"); ylabel("y_2[n]");
xticks([-32 -16 -12 -4 0 4 12 16 32]);
title("C3: y_2[n] = x_2[n] * h[n]");
axis([-32 32 -inf inf]);

%C4: plot X1[r], H[r], X2[r]
%{
clf;
subplot(311); stem(n, X1); axis([0 N_0 -inf inf]); title("C4: X_1[r]"); xlabel("r");
subplot(312); stem(n, H); axis([0 N_0 -inf inf]); title("H[r]"); xlabel("r");
subplot(313); stem(n, X2); axis([0 N_0 -inf inf]); title("X_2[r]"); xlabel("r");
%}

%C4: plot x1[n], h[n], x2[r]
%{
clf;
subplot(311); stem(n, x1); axis([0 N_0 -inf inf]); title("C4: x_1[n]"); xlabel("n");
h = real(ifft(H)*N_0);
subplot(312); stem(n, h); axis([0 N_0 -inf inf]); title("h[n]"); xlabel("n");
subplot(313); stem(n, x2); axis([0 N_0 -inf inf]); title("x_2[n]"); xlabel("n");
%}